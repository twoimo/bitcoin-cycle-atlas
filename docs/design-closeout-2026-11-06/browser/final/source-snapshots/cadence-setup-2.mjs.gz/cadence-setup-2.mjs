import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {resolve,relative,extname} from 'node:path';
import {chromium} from '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';

const root=resolve(fileURLToPath(new URL('../../../',import.meta.url)));
const output=resolve(root,process.env.ATLAS_CADENCE_OUT||'docs/design-closeout-2026-11-06/browser/cadence-diagnostic');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const cache=new Map(),served=new Map();
const report={kind:'native-cadence-diagnostic',status:'running',startedAt:new Date().toISOString(),
  sourceCommit:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),
  method:'Native pointer and keyboard in the actual weekly BTC chart. Observes public DOM mutations and real performance timestamps. Original 45000ms full-gate failure remains unchanged; this diagnostic observes whether the final bar arrives at the duration required by the real source count. No timers, replay state, source data, styles or gate assertions are patched.',
  inputs:[],screenshots:[],runtimeErrors:[],resourceFailures:[],servedHashes:{}};
await mkdir(output,{recursive:true});
const mime={'.html':'text/html','.css':'text/css','.js':'text/javascript','.json':'application/json','.svg':'image/svg+xml','.woff2':'font/woff2','.png':'image/png','.ico':'image/x-icon'};
const server=createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,'http://localhost');
    const path=resolve(root,'dist','.'+(url.pathname==='/'?'/index.html':decodeURIComponent(url.pathname)));
    const name=relative(root,path);assert.ok(name.startsWith('dist/'));
    if(!cache.has(name))cache.set(name,await readFile(path));
    const bytes=cache.get(name);served.set(name,sha(bytes));
    res.writeHead(200,{'Content-Type':mime[extname(path)]||'application/octet-stream','Cache-Control':'no-store'});res.end(bytes);
  }catch{res.writeHead(404);res.end('Not found');}
});
let browser,page;
const control=name=>'.chart-replay-controls [data-cr="'+name+'"]';
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function settle(){await page.evaluate(async()=>{await document.fonts.ready;await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));});await delay(150);}
async function click(selector){
  const hit=await page.locator(selector).evaluate(node=>{
    const b=node.getBoundingClientRect(),x=b.left+b.width/2,y=b.top+b.height/2,top=document.elementFromPoint(x,y);
    return {x,y,left:b.left,right:b.right,top:b.top,bottom:b.bottom,width:b.width,height:b.height,
      viewportWidth:innerWidth,viewportHeight:innerHeight,visible:node.checkVisibility({checkOpacity:true,checkVisibilityCSS:true}),
      topmost:top===node||node.contains(top),disabled:!!node.disabled};
  });
  assert.ok(hit.visible&&hit.topmost&&!hit.disabled&&hit.left>=0&&hit.top>=0&&hit.right<=hit.viewportWidth&&hit.bottom<=hit.viewportHeight,JSON.stringify({selector,hit}));
  report.inputs.push({type:'native-pointer',selector,...hit});await page.mouse.click(hit.x,hit.y);await settle();
}
async function key(value){report.inputs.push({type:'native-keyboard',key:value});await page.keyboard.press(value);}
async function select(selector,value){
  const options=await page.locator(selector).evaluate(node=>[...node.options].map(option=>option.value));
  const index=options.indexOf(value);assert.ok(index>=0);await click(selector);await key('Home');
  for(let step=0;step<index;step++)await key('ArrowDown');await key('Enter');
  await page.waitForFunction(({selector,value})=>document.querySelector(selector)?.value===value,{selector,value});
}
async function menu(view){
  if(!await page.locator(control('select-panel')).isVisible())await click(control('select-menu'));
  const current=await page.locator(control('select-panel')).getAttribute('data-menu-view');
  if(current!==view){
    if(current!=='start')await click(control('menu-back'));
    await click(control(view==='forecast'?'menu-settings':'select-date'));
  }
  await page.waitForFunction(({selector,view})=>document.querySelector(selector)?.dataset.menuView===view,{selector:control('select-panel'),view});
}
async function state(){return page.evaluate(()=>{
  const panel=document.querySelector('.chart-replay-controls'),svg=document.querySelector('#lab-chart'),q=name=>panel.querySelector('[data-cr="'+name+'"]');
  return {now:performance.now(),state:panel.dataset.state,origin:svg.dataset.replayOrigin,cursor:svg.dataset.replayCursor,
    index:Number(q('scrub').value),lastIndex:Number(q('scrub').max),speed:q('speed').value,mode:q('mode').value,
    frequency:document.querySelector('#workbench-interval-select').value,visibility:document.visibilityState,documentFocused:document.hasFocus(),
    playDisabled:q('play').disabled,nextDisabled:q('next').disabled,outputHash:svg.dataset.replayOutputHash,forecastValueSignature:svg.dataset.forecastValueSignature,
    observed:[...(globalThis.__cadenceDiagnosticObservations||[])]};
});}
async function screenshot(name){const file=name+'.png';const bytes=await page.screenshot({path:resolve(output,file)});report.screenshots.push({file,sha256:sha(bytes)});}
try{
  await new Promise((accept,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',accept);});
  const origin='http://127.0.0.1:'+server.address().port;
  browser=await chromium.launch({headless:true,executablePath:'/workspace/scratch/82e52cfd9693/browser-native/chromium-audit-multiprocess',args:['--no-sandbox','--disable-dev-shm-usage']});
  const context=await browser.newContext({viewport:{width:1440,height:900}});
  await context.route('**/*',route=>new URL(route.request().url()).origin===origin?route.continue():route.abort());
  page=await context.newPage();page.on('pageerror',error=>report.runtimeErrors.push(String(error)));page.on('requestfailed',request=>report.resourceFailures.push({url:request.url(),error:request.failure()?.errorText}));
  await page.goto(origin+'/?symbol=BTCUSD&granularity=daily&type=line');
  await page.waitForFunction(()=>document.documentElement.dataset.boot==='ready'&&document.querySelectorAll('#lab-chart path').length>0);
  await click('#workbench-replay');await page.waitForFunction(()=>document.querySelector('.chart-replay-controls')?.dataset.state==='selecting'&&document.querySelector('#lab-chart[data-chart-replay-active="true"] [data-chart-replay-overlay]'));await settle();
  await menu('forecast');await select(control('mode'),'atlas-chart');
  await page.waitForFunction(()=>document.querySelector('.chart-replay-controls')?.dataset.state==='selecting'&&document.querySelector('#lab-chart[data-chart-replay-active="true"] [data-chart-replay-overlay]'));await settle();
  await menu('date');assert.equal(await page.locator(control('date')).inputValue(),'2026-10-21');
  await click(control('start'));await page.waitForFunction(()=>document.querySelector('.chart-replay-controls')?.dataset.state==='paused'&&document.querySelector('#lab-chart[data-chart-replay-active="true"] [data-chart-replay-overlay]'));await settle();
  if(await page.locator(control('select-panel')).isVisible())await click(control('select-close'));
  await click('#workbench-interval-weekly');await page.waitForFunction(()=>document.querySelector('#workbench-interval-select').value==='weekly'&&document.querySelector('.chart-replay-controls').dataset.state==='paused');
  await select(control('speed'),'0.3');await click(control('first'));
  report.initial=await state();assert.equal(report.initial.origin,'2026-10-20');assert.equal(report.initial.index,0);
  const archive=JSON.parse(await readFile(resolve(root,'dist/data/btc-volume.json'),'utf8'));
  report.expectedDates=archive.bars.filter(row=>row.date>report.initial.origin).map(row=>row.date);
  assert.equal(report.initial.lastIndex,report.expectedDates.length);
  report.originalGateBudgetMs=45000;report.expectedIntervalMs=3000;
  report.minimumPlaybackDurationMs=report.initial.lastIndex*report.expectedIntervalMs;
  await page.evaluate(()=>{
    const svg=document.querySelector('#lab-chart');let previous=svg.dataset.replayCursor;
    globalThis.__cadenceDiagnosticObservations=[];
    globalThis.__cadenceDiagnosticObserver=new MutationObserver(()=>{
      const cursor=svg.dataset.replayCursor;if(cursor&&cursor!==previous){globalThis.__cadenceDiagnosticObservations.push({cursor,at:performance.now()});previous=cursor;}
    });
    globalThis.__cadenceDiagnosticObserver.observe(svg,{attributes:true,attributeFilter:['data-replay-cursor']});
  });
  await click(control('play'));report.started=await state();
  const observationBudget=Math.ceil(report.minimumPlaybackDurationMs*1.3+5000),end=Date.now()+observationBudget;
  while(Date.now()<end){
    const value=await state();value.elapsedMs=value.now-report.started.now;
    if(!report.atOriginalDeadline&&value.elapsedMs>=report.originalGateBudgetMs){report.atOriginalDeadline=value;await screenshot('at-original-45000ms-deadline');}
    if(value.state==='ended'){report.terminal=value;break;}
    await delay(100);
  }
  assert.ok(report.terminal,'Diagnostic observed no terminal state within source-count-derived observation horizon');
  await screenshot('native-terminal-state');
  const observations=report.terminal.observed;
  report.intervals=observations.slice(1).map((row,index)=>row.at-observations[index].at);
  report.meanIntervalMs=report.intervals.reduce((sum,n)=>sum+n,0)/report.intervals.length;
  assert.deepEqual(observations.map(row=>row.cursor),report.expectedDates);
  assert.equal(report.terminal.index,report.initial.lastIndex);assert.equal(report.terminal.cursor,report.expectedDates.at(-1));
  assert.equal(report.runtimeErrors.length,0);
  report.status='diagnosed';report.conclusion='Original deadline expires before the mathematically necessary full-source playback duration; the native product subsequently reaches its actual final observation at the requested cadence.';
}catch(error){report.status='diagnostic-failed';report.error=String(error.stack||error);process.exitCode=1;if(page)await screenshot('diagnostic-failure').catch(()=>{});}
finally{
  report.probeSha256=sha(await readFile(fileURLToPath(import.meta.url)));report.servedHashes=Object.fromEntries([...served].sort());report.changedSources=[];
  for(const [file,hash]of served)if(sha(await readFile(resolve(root,file)))!==hash)report.changedSources.push(file);
  if(report.changedSources.length){report.status='source-changed';process.exitCode=1;}
  await browser?.close();await new Promise(accept=>server.close(accept));report.finishedAt=new Date().toISOString();
  await writeFile(resolve(output,'report.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({status:report.status,initial:report.initial&&{origin:report.initial.origin,index:report.initial.index,lastIndex:report.initial.lastIndex,speed:report.initial.speed,frequency:report.initial.frequency},minimumPlaybackDurationMs:report.minimumPlaybackDurationMs,originalGateBudgetMs:report.originalGateBudgetMs,atOriginalDeadline:report.atOriginalDeadline&&{state:report.atOriginalDeadline.state,index:report.atOriginalDeadline.index,cursor:report.atOriginalDeadline.cursor,elapsedMs:report.atOriginalDeadline.elapsedMs},terminal:report.terminal&&{state:report.terminal.state,index:report.terminal.index,cursor:report.terminal.cursor,elapsedMs:report.terminal.elapsedMs},meanIntervalMs:report.meanIntervalMs,error:report.error,changedSources:report.changedSources}));
}
