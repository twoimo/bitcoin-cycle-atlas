// Observation-only Playwright adapter for diagnosing route-cancelled requests.
// It leaves browser configuration, product responses, inputs and assertions unchanged.
import {chromium as nativeChromium} from '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import {writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const events=[];
const record=(event,details={})=>events.push({at:new Date().toISOString(),event,...details});
let pageNumber=0;

export const chromium={
  async launch(options){
    const browser=await nativeChromium.launch(options);
    const nativeNewContext=browser.newContext.bind(browser);
    browser.newContext=async contextOptions=>{
      const context=await nativeNewContext(contextOptions);
      context.on('page',page=>{
        const pageId=++pageNumber;
        const requestStarts=new WeakMap();
        page.on('request',request=>{
          const start={pageId,url:request.url(),pageUrl:page.url(),resourceType:request.resourceType()};
          requestStarts.set(request,start);
          if(request.url().includes('project-replay-baseline.js'))record('replay-module-request',start);
        });
        page.on('requestfailed',request=>record('requestfailed',{
          pageId,...requestStarts.get(request),currentPageUrl:page.url(),
          error:request.failure()?.errorText,
        }));
        page.on('framenavigated',frame=>{
          if(frame===page.mainFrame())record('main-frame-navigation',{pageId,url:frame.url()});
        });
        const nativeGoto=page.goto.bind(page);
        page.goto=async(url,gotoOptions)=>{
          record('goto-start',{pageId,from:page.url(),to:url});
          try{return await nativeGoto(url,gotoOptions);}
          finally{record('goto-finished',{pageId,url:page.url()});}
        };
        page.on('close',()=>record('page-closed',{pageId}));
      });
      return context;
    };
    const nativeClose=browser.close.bind(browser);
    browser.close=async()=>{
      try{return await nativeClose();}
      finally{
        await writeFile(resolve(process.env.ATLAS_REQUEST_EVENTS_OUT),JSON.stringify({
          method:'Observation-only wrapper: unchanged browser launch options, original probe assertions and product bytes; records native request and navigation events.',
          events,
        },null,2)+'\n');
      }
    };
    return browser;
  },
};
