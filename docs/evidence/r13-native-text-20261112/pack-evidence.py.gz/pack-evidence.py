#!/usr/bin/env python3
import datetime
import gzip
import hashlib
import json
import pathlib
import re
import shutil
import subprocess

root=pathlib.Path('/workspace/scratch/a7a56e32088b/bitcoin-cycle-atlas')
run=root/'build/r13-native-text'
out=root/'docs/evidence/r13-native-text-20261112'
runtime=pathlib.Path('/workspace/scratch/a7a56e32088b/browser-r13-type-runtime')
source='74653b1979af0515ca0fed698dd2852c7a9cef29'
base='7f2982d944e329f3f00ecd0a592d22117eac6032'
def digest(b): return hashlib.sha256(b).hexdigest()
def read_json(p): return json.loads(p.read_text())
def git(*args): return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def json_bytes(d): return (json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
assert not out.exists()
execution=read_json(run/'verification/executions.json')
assert execution['status'] in ['passed','failed'] and execution['sourceCommit']==source and execution['finishedAt']
assert git('rev-parse','HEAD')==source
assert git('rev-parse','HEAD^{tree}')==execution['sourceTree']
assert not git('diff','--name-only',base,source,'--','dist','scripts/verify-page-heading-browser.mjs','scripts/native-select-keyboard.mjs')
for path,sha in execution['sourceHashes'].items(): assert digest((root/path).read_bytes())==sha,path
assert [e['id'] for e in execution['executions']]==['unit','conference']
for e in execution['executions']:
    b=(run/'verification'/e['log']).read_bytes()
    assert e['exitCode'] in [0,1] and e['sourceUnchanged'] and not e['signal'] and not e['error']
    assert len(b)==e['logBytes'] and digest(b)==e['logSha256']
log=(run/'verification/unit.log').read_text()
unit={key:int(re.findall(r'^[#ℹ] '+key+r' (\d+)$',log,re.M)[-1]) for key in ['tests','pass','fail','skipped']}
assert unit=={'tests':31,'pass':31,'fail':0,'skipped':0}
report=read_json(run/'conference/report.json')
assert report['sourceCommit']==source and report['status'] in ['passed','failed'] and not report['workingChanges']
assert len(report['cases'])==14
assert report['sourceIntegrity']['unchangedDuringRun'] and not report['sourceIntegrity']['changedSources']
inputs=[{'caseId':c['id'],**x} for c in report['cases'] for x in c.get('nativeTextInputs',[])]
assert len(inputs)==19 and all(x['observed']==x['requested'] and x['platform']=='linux' and x['modifiers']==2 for x in inputs)
fixtures=[c for c in report['cases'] if c['id'].startswith('fixture-')]
assert len(fixtures)==9
assert all(c['status']=='passed' and not c['failures'] for c in fixtures)
for c in fixtures:
    searches=[x for x in c['nativeTextInputs'] if x['selector']=='[data-role=transcript-search]']
    assert len(searches)==2 and all(x['requested']==x['observed']=='3725초' for x in searches),c['id']
pages=[x for x in inputs if x['selector']=='[data-role=page]']
assert len(pages)==1 and pages[0]['observed']=='2' and pages[0]['selection']['start'] is None and pages[0]['selection']['end'] is None
selections=[x for c in report['cases'] for x in c.get('nativeSelections',[])]
events=[event for x in selections for event in x['events']]
assert events and all(e['isTrusted'] for e in events)
pngs=[]
for item in report['screenshots']:
    file=run/'conference'/item['file']; b=file.read_bytes()
    assert b[:8]==b'\x89PNG\r\n\x1a\n' and len(b)==item['bytes'] and digest(b)==item['sha256']
    pngs.append({**item,'retained':item['file'] in ['fixture-320x740-transcript.png','fixture-1440x900-transcript.png']})
assert len(pngs)==24 and sum(p['retained'] for p in pngs)==2
first=root/'build/r13-native-text-attempt-1'
preserved=read_json(first/'preservation.json')
for item in preserved['preservedFiles']:
    b=(first/item['file']).read_bytes();assert len(b)==item['bytes'] and digest(b)==item['sha256']
recovered=root/'build/r13-native-text-recovered-attempt-1'
excerpt_manifest=read_json(recovered/'excerpt-manifest.json')
assert excerpt_manifest['fullReportRecovered'] is False
for item in excerpt_manifest['files']:
    b=(recovered/item['file']).read_bytes();assert len(b)==item['bytes'] and digest(b)==item['sha256']
def verify_failure_png(value):
    if isinstance(value,dict):
        if str(value.get('file','')).endswith('.png'):
            b=(first/value['file']).read_bytes();assert len(b)==value['bytes'] and digest(b)==value['sha256']
        for child in value.values(): verify_failure_png(child)
    elif isinstance(value,list):
        for child in value: verify_failure_png(child)
verify_failure_png(read_json(recovered/'observed-failed-case-excerpt.json'))

# Restore only this task's isolated certificate runtime after its browsers exit.
setup=read_json(runtime/'setup.json')
active=[]
for proc in pathlib.Path('/proc').iterdir():
    if not proc.name.isdigit(): continue
    try:
        env=(proc/'environ').read_bytes().split(b'\0'); command=(proc/'cmdline').read_bytes().lower()
        if ('XDG_DATA_HOME='+setup['xdgDataHome']).encode() in env and (b'chrome' in command or b'chromium' in command): active.append(int(proc.name))
    except OSError: pass
assert not active,active
nss=pathlib.Path('/home/agent/.local/share/pki/nssdb')
after={p.name:digest(p.read_bytes()) for p in nss.iterdir() if p.is_file()}
assert after==setup['userNssBefore']
assert digest(pathlib.Path(setup['source']).read_bytes())==setup['sourceSha256']
assert not pathlib.Path('/home/agent/.pki/nssdb').exists()
database=pathlib.Path(setup['database']);assert database==runtime/'xdg-data/pki/nssdb' and not database.is_symlink()
if database.exists():
    shutil.rmtree(database)
    cleanup={'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'taskOnlyDatabaseRemoved':str(database),
        'activeTaskBrowserProcesses':active,'userNssUnchanged':True,'userNssAfter':after,'systemCaUnchanged':True,'legacyNssAbsent':True,
        'certificateValidationDisabled':False,'accountOrPermissionChanges':False}
else:
    cleanup=read_json(run/'runtime/cleanup.json')
    assert cleanup['taskOnlyDatabaseRemoved']==str(database) and cleanup['userNssAfter']==after
(run/'runtime').mkdir(exist_ok=True)
shutil.copyfile(runtime/'setup.json',run/'runtime/setup.json')
(run/'runtime/cleanup.json').write_bytes(json_bytes(cleanup))
shutil.copyfile(__file__,run/'pack-evidence.py')

summary={'kind':'r13-native-text-follow-up','sourceCommit':source,'sourceTree':execution['sourceTree'],'baseCommit':base,
    'recordedAt':cleanup['recordedAt'],'status':report['status'],'productionDeployment':False,'environment':execution['environment'],
    'browserVersion':report.get('browserVersion'),'unit':{**unit,'nativeInputTests':9,'existingNativeSelectTests':22,'platformCoverage':'Mocked CDP transport branches for darwin/linux/win32; not macOS browser execution'},
    'conference':{'total':14,'passed':sum(c['status']=='passed' for c in report['cases']),'failed':sum(c['status']!='passed' for c in report['cases']),
        'cases':[{'id':c['id'],'status':c['status'],'failures':c['failures']} for c in report['cases']]},
    'nativeTextInput':{'total':len(inputs),'exactReadbacks':len(inputs),'transcriptSearches':18,'pageInputs':1,'receipts':inputs},
    'nativeSelect':{'calls':len(selections),'trustedEvents':len(events),'untrustedEvents':0},
    'sourceIntegrity':report['sourceIntegrity'],'protectedPathsUnchanged':execution['protectedPathsUnchanged'],
    'screenshots':{'verified':len(pngs),'retained':2,'receipts':pngs},
    'executions':execution['executions'],
    'userReportedMacOSAtBase':{'source':'User-provided follow-up report; not independently rerun here','chrome':'157.0.8103.79',
        'heading':{'contract':15,'supplemental':9,'layoutShift':2,'failures':0,'h1Top':[869.5,797.5,869.5]},'conference':{'passed':5,'total':14,'failure':'Repeated transcript search appended because type() used Control+A on macOS'}},
    'remaining':['Independent macOS conference 14-case remeasurement of this follow-up','Unchanged navigationState can read documentElement.scrollWidth while documentElement is null during destination navigation','Previously reported initial pageshow playback reset remains outside this text-input fix'],
    'priorAttempts':{'firstCompleted':{'total':14,'passed':13,'failed':1,'failedCase':'navigation-ETHUSD','sourceCommit':source,
        'evidenceLimitation':'The first full report.json and executions.json were overwritten after an archive-precondition failure was followed by an accidental retry. Original completed stdout, failure screenshot and previously observed excerpts are preserved; the lost files are not reconstructed.'},
        'interruptedRetry':{'observedCases':1,'passed':1,'exitCode':130,'complete':False},
        'finalRun':'One deliberate full rerun of the identical source after preserving remaining evidence. Prior attempts are not combined with final counts.'}}
archive={};manifest=[]
originals=['verification/executions.json','verification/unit.log','verification/conference.log','conference/report.json','conference/chrome.stderr.log','run-verification.mjs','runtime/setup.json','runtime/cleanup.json','pack-evidence.py','repeat-reason.json']
for path in originals:
    b=(run/path).read_bytes();stored=gzip.compress(b,compresslevel=9,mtime=0);assert gzip.decompress(stored)==b
    name=path+'.gz';archive[name]=stored;manifest.append({'file':name,'bytes':len(stored),'sha256':digest(stored),'original':path,'originalBytes':len(b),'originalSha256':digest(b)})
for item in pngs:
    if item['retained']:
        name='conference/'+item['file'];b=(run/name).read_bytes();archive[name]=b;manifest.append({'file':name,'bytes':len(b),'sha256':digest(b)})
previous=[
    (root/'build/r13-native-text-attempt-1','prior-attempt-1',None),
    (root/'build/r13-native-text-recovered-attempt-1','prior-attempt-1-excerpts',None),
    (root/'build/r13-native-text-interrupted-2','interrupted-retry',{
        'conference/report.json','verification/executions.json','verification/unit.log','run-verification.mjs','interruption.json'}),
]
for directory,prefix,allowed in previous:
    assert directory.is_dir(),str(directory)
    for path in sorted(p for p in directory.rglob('*') if p.is_file()):
        relative=path.relative_to(directory).as_posix()
        if allowed is not None and relative not in allowed: continue
        b=path.read_bytes();name=prefix+'/'+relative
        if path.suffix=='.png':
            assert b[:8]==b'\x89PNG\r\n\x1a\n';stored=b
        else:
            name+='.gz';stored=gzip.compress(b,compresslevel=9,mtime=0);assert gzip.decompress(stored)==b
        archive[name]=stored;manifest.append({'file':name,'bytes':len(stored),'sha256':digest(stored),'original':str(path.relative_to(root)),
            'originalBytes':len(b),'originalSha256':digest(b),'provenance':'See prior-attempt preservation and excerpt provenance; no lost full report reconstruction.'})
archive['summary.json']=json_bytes(summary)
manifest.append({'file':'summary.json','bytes':len(archive['summary.json']),'sha256':digest(archive['summary.json'])})
archive['manifest.json']=json_bytes({'sourceCommit':source,'note':'Original report/log/runtime/runner bytes are gzip-compressed unchanged; all PNGs verified and two retained.','files':manifest})
archive['SHA256SUMS']=''.join(digest(b)+'  '+name+'\n' for name,b in sorted(archive.items())).encode()
assert git('rev-parse','HEAD')==source
out.mkdir()
for name,b in archive.items():
    target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
print(json.dumps({'out':str(out),'sourceCommit':source,'files':len(archive),'bytes':sum(map(len,archive.values())),'unit':unit,'conference':summary['conference'],'nativeTextInput':{'total':19,'exactReadbacks':19},'nativeSelect':summary['nativeSelect']},ensure_ascii=False))
