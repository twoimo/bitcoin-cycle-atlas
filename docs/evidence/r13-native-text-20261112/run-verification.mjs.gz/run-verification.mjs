import assert from 'node:assert/strict';
import {spawn,execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {mkdir,readFile,writeFile,stat} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=process.cwd(),out=resolve(root,'build/r13-native-text/verification');
for(const path of [resolve(out,'executions.json'),resolve(root,'build/r13-native-text/conference')]){
  await assert.rejects(stat(path),{code:'ENOENT'},'Refuse to overwrite a prior execution: '+path);
}
const expected=process.argv[2],base='7f2982d944e329f3f00ecd0a592d22117eac6032';
const git=args=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim();
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
assert.match(expected||'',/^[a-f0-9]{40}$/);
assert.equal(git(['rev-parse','HEAD']),expected);
assert.equal(git(['status','--porcelain','--','dist','scripts','tests']),'');
const protectedPaths=['dist','scripts/verify-page-heading-browser.mjs','scripts/native-select-keyboard.mjs'];
assert.equal(git(['diff','--name-only',base,expected,'--',...protectedPaths]),'');
const files=['scripts/native-input-keyboard.mjs','scripts/verify-conference-browser.mjs','tests/native-input-keyboard.test.mjs',
  'scripts/native-select-keyboard.mjs','tests/native-select-keyboard.test.mjs','scripts/verify-page-heading-browser.mjs'];
const sourceHashes=Object.fromEntries(await Promise.all(files.map(async file=>[file,hash(await readFile(resolve(root,file)))])));
const node='/workspace/scratch/55a6bfaf803b/conference-tools/node-v24.22.2-linux-x64/bin/node';
assert.equal(process.version,'v24.22.2');assert.equal(process.platform,'linux');assert.equal(process.arch,'x64');
const browser='/workspace/scratch/55a6bfaf803b/conference-tools/chrome-with-proxy';
const xdg='/workspace/scratch/a7a56e32088b/browser-r13-type-runtime/xdg-data';
const env={...process.env,PATH:resolve(node,'..')+':'+process.env.PATH,ATLAS_BROWSER_PATH:browser,XDG_DATA_HOME:xdg};
const report={kind:'r13-native-text-linux-verification',startedAt:new Date().toISOString(),status:'running',sourceCommit:expected,
  sourceTree:git(['rev-parse','HEAD^{tree}']),baseCommit:base,sourceHashes,protectedPathsUnchanged:protectedPaths,
  productionDeployment:false,environment:{platform:process.platform,arch:process.arch,node:process.version,browser,
    browserLauncherSha256:hash(await readFile(browser)),xdgDataHome:xdg},executions:[]};
await mkdir(out,{recursive:true});
const save=()=>writeFile(resolve(out,'executions.json'),JSON.stringify(report,null,2)+'\n');
await save();
const gates=[['unit',['--test','tests/native-input-keyboard.test.mjs','tests/native-select-keyboard.test.mjs']],
  ['conference',['scripts/verify-conference-browser.mjs','--out','build/r13-native-text/conference']]];
for(const [id,args] of gates){
  assert.equal(git(['rev-parse','HEAD']),expected);
  const entry={id,command:[node,...args],cwd:root,startedAt:new Date().toISOString(),log:id+'.log'};
  report.executions.push(entry);await save();console.log(JSON.stringify({event:'start',id}));
  const start=Date.now(),chunks=[];
  const result=await new Promise(accept=>{
    const child=spawn(node,args,{cwd:root,env,stdio:['ignore','pipe','pipe']});
    const collect=chunk=>{chunks.push(Buffer.from(chunk));if(id==='conference')process.stdout.write(chunk);};
    child.stdout.on('data',collect);child.stderr.on('data',collect);
    child.on('error',error=>accept({exitCode:1,signal:null,error:String(error.stack||error)}));
    child.on('close',(exitCode,signal)=>accept({exitCode,signal,error:null}));
  });
  const bytes=Buffer.concat(chunks);await writeFile(resolve(out,entry.log),bytes);
  Object.assign(entry,result,{finishedAt:new Date().toISOString(),durationMs:Date.now()-start,logBytes:bytes.length,logSha256:hash(bytes)});
  assert.equal(git(['rev-parse','HEAD']),expected);
  assert.equal(git(['status','--porcelain','--','dist','scripts','tests']),'');
  for(const [file,digest] of Object.entries(sourceHashes))assert.equal(hash(await readFile(resolve(root,file))),digest,file);
  entry.sourceUnchanged=true;await save();
  console.log(JSON.stringify({event:'finish',id,exitCode:entry.exitCode,durationMs:entry.durationMs,
    ...(id==='unit'?{tail:bytes.toString('utf8').split('\n').slice(-9).join('\n')}:{})}));
}
report.finishedAt=new Date().toISOString();report.status=report.executions.every(item=>item.exitCode===0&&!item.signal&&!item.error)?'passed':'failed';
await save();console.log(JSON.stringify({event:'complete',status:report.status,sourceCommit:expected}));
process.exitCode=report.status==='passed'?0:1;
