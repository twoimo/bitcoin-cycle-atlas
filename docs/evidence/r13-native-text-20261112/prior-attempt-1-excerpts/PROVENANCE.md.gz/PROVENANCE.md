# Partial evidence recovered from a prior tool output

This directory is **not the original complete conference report**. The original report was overwritten by an interrupted subsequent execution. The reviewing agent did not retain the complete report bytes in a file, `functions.store`, or another runtime object.

The files here preserve only fields actually printed by the reviewing agent's earlier read of `build/r13-native-text/conference/report.json`. That read completed before the overwrite, in `exec_command` output chunk `7f7336` (exit code 0). It parsed the original JSON, printed report metadata and all case IDs/statuses, printed the complete failing `navigation-ETHUSD` case with Python `json.dumps(..., ensure_ascii=False, indent=2)`, and counted the text readbacks. This is a transcription of that already-observed tool output; it is not a recovered copy of the original report bytes and does not establish the original file's SHA-256.

- `observed-summary-excerpt.json`: the observed source SHA, report status, source-integrity fields, all 14 case IDs/statuses, and the calculated 19/19 text-readback count. The summary field names for the calculated totals are explanatory, not claims about the original report schema.
- `observed-failed-case-excerpt.json`: the complete failing case object printed in that tool output. It is only one case, not the full report.

The reviewer also compared `navigationState()` in `7f2982d` and current `74653b1979af0515ca0fed698dd2852c7a9cef29`. Its extracted function body was identical; that body hash was `5335ca409f7e38bf6fc133bd497a9297cda295281d79382175b2186246c2de01` (read-only tool output chunk `375054`). This establishes unchanged source for that reader; it does not replace missing execution evidence.

No source, current report directory, browser, test, branch, or HEAD was modified during this recovery. Only this separate partial-evidence directory was written.
