#!/usr/bin/env node
// Task-local evidence packer. Run only after the declared gates have finished.
// Does not alter test results, product bytes, thresholds, or original receipts.
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFile, writeFile, readdir, mkdir, lstat, rename, rm} from 'node:fs/promises';
import {resolve, relative, dirname, sep, isAbsolute} from 'node:path';
import {gzipSync, gunzipSync} from 'node:zlib';

const argv = process.argv.slice(2);
const option = (name, fallback) => argv.includes(name) ? argv[argv.indexOf(name) + 1] : fallback;
const root = resolve(option('--repo', '/workspace/scratch/a7a56e32088b/bitcoin-cycle-atlas'));
const output = resolve(root, option('--out', 'docs/evidence/r13-harness-20261112'));
const runRoot = resolve(root, 'build/r13'), diagnosticRoot = resolve(root, 'build/r13-diagnostics');
const interruptedRoot = resolve(root, 'build/r13-attempt-1');
const git = args => execFileSync('git', args, {cwd:root, encoding:'utf8'}).trim();
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const jsonBytes = object => Buffer.from(JSON.stringify(object, null, 2) + '\n');
const passed = status => ['passed', 'pass'].includes(String(status).toLowerCase());
const slash = path => path.split(sep).join('/');
function inside(base, file) {
  const rel = relative(base, file);
  assert.ok(rel !== '..' && !rel.startsWith('..' + sep) && !isAbsolute(rel), 'Path escapes evidence scope: ' + file);
  return slash(rel);
}
async function filesBelow(directory, optional = false) {
  let entries;
  try { entries = await readdir(directory, {withFileTypes:true}); }
  catch (error) { if (optional && error.code === 'ENOENT') return []; throw error; }
  const files = [];
  for (const entry of entries.sort((a,b) => a.name.localeCompare(b.name))) {
    const file = resolve(directory, entry.name);
    assert.ok(!entry.isSymbolicLink(), 'Evidence input must not be a symlink: ' + file);
    if (entry.isDirectory()) files.push(...await filesBelow(file));
    else if (entry.isFile()) files.push(file);
  }
  return files;
}
const inputBytes = new Map(), reports = new Map();
async function read(file) {
  if (!inputBytes.has(file)) inputBytes.set(file, await readFile(file));
  return inputBytes.get(file);
}
async function readJson(file) {
  if (!reports.has(file)) reports.set(file, JSON.parse((await read(file)).toString('utf8')));
  return reports.get(file);
}
const reportFile = name => resolve(runRoot, name);
const executionFile = reportFile('verification/executions.json');
const execution = await readJson(executionFile);
assert.equal(execution.kind, 'r13-linux-verification');
assert.ok(['passed','failed'].includes(execution.status), 'Verification is not finished');
assert.ok(execution.finishedAt, 'Verification completion timestamp missing');
assert.match(execution.sourceCommit || '', /^[a-f0-9]{40}$/);
const expectedSource = option('--expected-source', execution.sourceCommit);
assert.equal(execution.sourceCommit, expectedSource, 'Verification source differs from requested source');
assert.equal(git(['rev-parse','HEAD']), expectedSource, 'Current HEAD differs from tested source');
assert.equal(git(['rev-parse','HEAD^{tree}']), execution.sourceTree, 'Tested tree differs');
git(['diff','--exit-code','HEAD','--','dist','scripts','tests']);
assert.ok(Object.keys(execution.sourceHashes || {}).length > 0, 'Source inventory missing');
for (const [file, hash] of Object.entries(execution.sourceHashes)) {
  inside(root, resolve(root,file));
  assert.equal(sha(await readFile(resolve(root,file))), hash, 'Tested source bytes changed: ' + file);
}
const expectedExecutions = ['conference','heading','native-53','r10-regressions','npm-test'];
assert.deepEqual(execution.executions.map(item=>item.id), expectedExecutions, 'Execution inventory changed/incomplete');
for (const entry of execution.executions) {
  assert.ok(entry.finishedAt && Number.isInteger(entry.exitCode), 'Unfinished gate: ' + entry.id);
  const file = resolve(dirname(executionFile), entry.log); inside(dirname(executionFile),file);
  const bytes = await read(file);
  assert.equal(bytes.length, entry.logBytes, 'Gate log size mismatch: ' + entry.id);
  assert.equal(sha(bytes), entry.logSha256, 'Gate log digest mismatch: ' + entry.id);
  assert.equal(entry.sourceUnchanged, true, 'Gate source check missing: ' + entry.id);
}

const required = [
  ['conference/report.json','conference'], ['heading/report.json','heading'],
  ['native-53/report.json','native-53'], ['native-53/lanes/non-chart-replay/report.json','native-53'],
  ['native-53/lanes/chart-replay/report.json','native-53'], ['r10/summary.json','r10-regressions'],
  ...['responsive-BTCUSD','responsive-ETHUSD','responsive-MSTR','responsive-BMNR','wp6','chart-qa'].map(name=>['r10/'+name+'/report.json','r10-regressions']),
];
for (const [name, executionId] of required) {
  const report = await readJson(reportFile(name));
  const entry = execution.executions.find(item=>item.id===executionId);
  const stamp = report.startedAt || report.recordedAt;
  assert.ok(Number.isFinite(Date.parse(stamp)), 'Report lacks a capture timestamp: ' + name);
  assert.ok(Date.parse(stamp) >= Date.parse(entry.startedAt) && Date.parse(stamp) <= Date.parse(entry.finishedAt), 'Stale/out-of-run report: ' + name);
  for (const source of [report.sourceCommit,report.testedHead,report.inspector?.sourceCommit,report.candidateSourceBefore?.sourceCommit,report.candidateSourceAfter?.sourceCommit].filter(Boolean)) {
    assert.equal(source, expectedSource, 'Mixed source report: ' + name);
  }
}
const acceptanceCandidates = (await filesBelow(runRoot)).filter(file=>/\.(?:json|jsonl|log|mjs|txt)$/.test(file));
const replayDownloadFiles = acceptanceCandidates.filter(file=>slash(file).includes('/chart-replay-downloads/'));
const acceptanceFiles = acceptanceCandidates.filter(file=>!replayDownloadFiles.includes(file));
const diagnosticFiles = (await filesBelow(diagnosticRoot,true)).filter(file=>/\.(?:json|jsonl|log|mjs|txt)$/.test(file));
const interruptedFiles = (await filesBelow(interruptedRoot,true)).filter(file=>/\.(?:json|jsonl|log|mjs|txt|bundle)$/.test(file));
for (const file of [...acceptanceFiles,...diagnosticFiles,...interruptedFiles]) {
  if (file.endsWith('.json')) await readJson(file); else await read(file);
}
let interruptedSummary = null;
if (interruptedFiles.length) {
  const interruption = await readJson(resolve(interruptedRoot,'interruption.json'));
  const previous = await readJson(resolve(interruptedRoot,'conference/report.json'));
  const previousExecution = await readJson(resolve(interruptedRoot,'verification/executions.json'));
  await read(resolve(interruptedRoot,'verification/conference.log'));
  // An interrupted runner legitimately has no finishedAt/log digest and may
  // still say running. Preserve that original receipt; do not synthesize finish.
  assert.equal(interruption.status,'interrupted');
  assert.equal(previous.sourceCommit,interruption.sourceCommit);
  assert.equal(previousExecution.sourceCommit,interruption.sourceCommit);
  const observed={total:previous.cases.length,passed:previous.cases.filter(item=>passed(item.status)).length,
    failed:previous.cases.filter(item=>!passed(item.status)).length};
  assert.equal(observed.total,interruption.observedCases);
  assert.equal(observed.passed,interruption.passed);assert.equal(observed.failed,interruption.failed);
  interruptedSummary={id:'attempt-1',scope:'Interrupted integration attempt only; excluded from final acceptance totals',
    status:'interrupted',exitCode:interruption.exitCode,sourceCommit:interruption.sourceCommit,counts:observed,
    originalRunnerStatus:previousExecution.status,startedGates:previousExecution.executions.map(item=>item.id),
    report:'interrupted-attempt-1/conference/report.json.gz',reason:interruption.reason,
    failures:previous.failures??[],cases:previous.cases.map(item=>({id:item.id,status:item.status,failures:item.failures??[]}))};
}
// Verify source-bound diagnostic probes independently; they are never counted
// as post-load acceptance cases.
for (const manifestName of ['probes/manifest.json','probes/desktop-click-manifest.json']) {
  const probeManifest = resolve(diagnosticRoot,manifestName);
  if (!reports.has(probeManifest)) continue;
  const value = reports.get(probeManifest);
  for (const probe of Array.isArray(value) ? value : [value]) {
    for (const key of ['probe','report']) {
      const file = resolve(root,probe[key]); inside(diagnosticRoot,file);
      assert.equal(sha(await read(file)),probe[key+'Sha256'],'Diagnostic '+key+' changed: '+(probe.id||manifestName));
    }
  }
}

const pngs = new Map();
async function verifyPngReceipts(value, origin, pointer = '$') {
  if (!value || typeof value !== 'object') return;
  if (typeof value.file === 'string' && /\.png$/i.test(value.file) && ('bytes' in value || 'sha256' in value || /screenshots?/i.test(pointer))) {
    assert.ok(Number.isSafeInteger(value.bytes) && value.bytes > 8, 'Missing PNG size: ' + origin + pointer);
    assert.match(value.sha256 || '', /^[a-f0-9]{64}$/, 'Missing PNG digest: ' + origin + pointer);
    assert.ok(!isAbsolute(value.file), 'PNG receipt must be relative: ' + value.file);
    const file = resolve(dirname(origin),value.file); inside(dirname(origin),file);
    const current = pngs.get(file);
    if (current) {
      assert.equal(current.bytes,value.bytes,'Conflicting PNG size receipts');
      assert.equal(current.sha256,value.sha256,'Conflicting PNG hash receipts');
      current.references.push({report:inside(root,origin),pointer});
    } else {
      const bytes = await readFile(file);
      assert.equal(bytes.length,value.bytes,'PNG size mismatch: '+file);
      assert.equal(sha(bytes),value.sha256,'PNG hash mismatch: '+file);
      assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a','Invalid PNG signature: '+file);
      pngs.set(file,{source:inside(root,file),bytes:bytes.length,sha256:sha(bytes),references:[{report:inside(root,origin),pointer}],retainedAs:null});
    }
  }
  for (const [key,item] of Object.entries(value)) await verifyPngReceipts(item,origin,pointer+'.'+key);
}
for (const [file,report] of reports) await verifyPngReceipts(report,file);

// Generated model/replay downloads are large copies of existing product data.
// Verify every original against its report receipt and retain their inventory,
// while keeping every report/log/probe byte stream unchanged in the archive.
const replayDownloads = new Map();
async function verifyReplayDownloadReceipts(value, origin, pointer = '$') {
  if (!value || typeof value !== 'object') return;
  if (typeof value.file === 'string' && value.file.includes('chart-replay-downloads/') && /\.json$/i.test(value.file)) {
    assert.ok(Number.isSafeInteger(value.bytes) && value.bytes > 0, 'Missing download size: ' + origin + pointer);
    assert.match(value.sha256 || '', /^[a-f0-9]{64}$/, 'Missing download digest: ' + origin + pointer);
    assert.ok(!isAbsolute(value.file), 'Download receipt must be relative');
    const file = resolve(dirname(origin),value.file); inside(dirname(origin),file);
    const current = replayDownloads.get(file);
    if (current) {
      assert.equal(current.bytes,value.bytes,'Conflicting download size receipts');
      assert.equal(current.sha256,value.sha256,'Conflicting download hash receipts');
      current.references.push({report:inside(root,origin),pointer});
    } else {
      const bytes = await readFile(file);
      assert.equal(bytes.length,value.bytes,'Download size mismatch: '+file);
      assert.equal(sha(bytes),value.sha256,'Download hash mismatch: '+file);
      JSON.parse(bytes.toString('utf8'));
      replayDownloads.set(file,{source:inside(root,file),bytes:bytes.length,sha256:sha(bytes),
        references:[{report:inside(root,origin),pointer}],retainedAs:null});
    }
  }
  for (const [key,item] of Object.entries(value)) await verifyReplayDownloadReceipts(item,origin,pointer+'.'+key);
}
for (const [file,report] of reports) await verifyReplayDownloadReceipts(report,file);
assert.deepEqual([...replayDownloads.keys()].sort(),replayDownloadFiles.sort(),'Unverified or unaccounted generated download');

const acceptanceIssues = [], failureRecords = [];
const check = (condition,message) => { if(!condition) acceptanceIssues.push(message); };
function counts(report, expected, label, cases = report.cases) {
  assert.ok(Array.isArray(cases),'Missing case array: '+label);
  const result={total:cases.length,passed:cases.filter(item=>passed(item.status)).length,failed:cases.filter(item=>!passed(item.status)).length,expected};
  check(result.total===expected,label+': case count '+result.total+' != '+expected);
  check(result.failed===0,label+': '+result.failed+' failed/uncompleted case(s)');
  check(passed(report.status),label+': report status '+report.status);
  return result;
}
for (const [name] of required) {
  const report=reports.get(reportFile(name));
  if (!passed(report.status)||report.error||report.cleanupError||report.failures?.length) {
    failureRecords.push({report:name,status:report.status,error:report.error??null,cleanupError:report.cleanupError??null,failures:report.failures??[]});
    check(false,name+': report contains failures');
  }
  for (const group of ['cases','supplementalCases','layoutShiftCases']) for (const item of report[group]||[]) {
    if (!passed(item.status)||item.error||item.failures?.length) failureRecords.push({report:name,group,id:item.id||item.label||item.caseSpec,status:item.status,error:item.error??null,failures:item.failures??[]});
  }
}
for (const entry of execution.executions) check(entry.exitCode===0&&!entry.signal&&!entry.error,entry.id+': execution did not exit cleanly');
const conference=reports.get(reportFile('conference/report.json')), heading=reports.get(reportFile('heading/report.json'));
const native=reports.get(reportFile('native-53/report.json')), r10=reports.get(reportFile('r10/summary.json'));
const caseCounts={conference:counts(conference,14,'conference'),heading:{
  contract:counts(heading,15,'heading contract'),supplemental:counts(heading,9,'heading supplemental',heading.supplementalCases),
  layoutShift:counts(heading,2,'heading layout shift',heading.layoutShiftCases)},native:counts(native,53,'native 53')};
const responsiveSymbols=['BTCUSD','ETHUSD','MSTR','BMNR'];
caseCounts.responsiveBySymbol=Object.fromEntries(responsiveSymbols.map(symbol=>[symbol,counts(reports.get(reportFile('r10/responsive-'+symbol+'/report.json')),11,'responsive '+symbol)]));
caseCounts.responsive={total:0,passed:0,failed:0,expected:44};
for(const result of Object.values(caseCounts.responsiveBySymbol))for(const key of ['total','passed','failed'])caseCounts.responsive[key]+=result[key];
caseCounts.wp6=counts(reports.get(reportFile('r10/wp6/report.json')),30,'WP6');
caseCounts.chartQa=counts(reports.get(reportFile('r10/chart-qa/report.json')),12,'chart-qa');
check(r10.gates?.length===6&&r10.gates.every(item=>passed(item.status)),'R10 wrapper inventory/status');

const selections=conference.cases.flatMap(item=>(item.nativeSelections||[]).map(selection=>({caseId:item.id,...selection})));
const selectEvents=selections.flatMap(item=>item.events||[]);
const nativeSelect={calls:selections.length,noOps:selections.filter(item=>item.noOp).length,
  changedSelections:selections.filter(item=>item.noOp===false).length,
  trustedEvents:selectEvents.filter(event=>event.isTrusted===true).length,untrustedEvents:selectEvents.filter(event=>event.isTrusted!==true).length,
  eventCounts:Object.fromEntries(['keydown','keyup','input','change'].map(type=>[type,selectEvents.filter(event=>event.type===type).length])),
  requestedKeys:selections.reduce((sum,item)=>sum+(item.keys?.length||0),0),platforms:[...new Set(selections.map(item=>item.platform))],
  caseCalls:conference.cases.filter(item=>item.nativeSelections).map(item=>({id:item.id,calls:item.nativeSelections.length})),
  allViewportsUseActualDesktopMetrics:selections.every(item=>item.viewport?.mobile===false)};
check(selections.length>0,'No native select receipts');check(nativeSelect.untrustedEvents===0,'Native select has untrusted/missing trust events');
for(const item of selections){
  const label=item.caseId+' '+item.selector+' '+item.value;
  check(Array.isArray(item.events)&&Array.isArray(item.keys),'Incomplete native select receipt: '+label);
  for(const type of ['keydown','keyup'])check(JSON.stringify((item.events||[]).filter(event=>event.type===type).map(event=>event.key))===JSON.stringify(item.keys),'Native select '+type+' sequence mismatch: '+label);
  check((item.events||[]).filter(event=>event.type==='keydown').every(event=>event.targetMatches),'Native select keydown owner mismatch: '+label);
  if(item.noOp===false)for(const type of ['input','change'])check(item.events?.some(event=>event.type===type&&event.targetMatches&&event.isTrusted),'Missing trusted '+type+': '+label);
  check(item.observed?.value===item.value,'Native select value readback mismatch: '+label);
}
const headingMotion=heading.layoutShiftCases.map(item=>{
  const result={id:item.id,status:item.status,expectedTopDelta:-72,tolerancePx:.01,beforeNotice:item.before?.btcRefreshNotice??null,
    toolbar:null,anchor:null,maxRestoredGeometryDelta:null,restoredGeometryDifferences:[],heading:{before:item.before?.heading??null,shifted:item.shifted?.heading??null,restored:item.restored?.heading??null}};
  if(!item.before||!item.shifted||!item.restored){check(false,item.id+': missing motion snapshots');return result;}
  for(const [name,before,after] of [['toolbar',item.before.geometry.toolbar,item.shifted.geometry.toolbar],['anchor',item.before.placement.anchor,item.shifted.placement.anchor]]){
    if(!before||!after){check(false,item.id+': missing '+name);continue;}
    result[name]={beforeTop:before.top,shiftedTop:after.top,topDelta:after.top-before.top,widthDelta:after.width-before.width,heightDelta:after.height-before.height};
    check(Math.abs(result[name].topDelta+72)<=.01&&Math.abs(result[name].widthDelta)<=.01&&Math.abs(result[name].heightDelta)<=.01,item.id+': '+name+' violates original 72px/.01px contract');
  }
  for(const [name,before] of Object.entries(item.before.geometry)){
    const after=item.restored.geometry[name];
    if(!before||!after){check(before===after,item.id+': restored '+name+' visibility mismatch');continue;}
    for(const field of ['left','top','width','height'])result.restoredGeometryDifferences.push({field:name+'.'+field,delta:after[field]-before[field]});
  }
  result.maxRestoredGeometryDelta=Math.max(0,...result.restoredGeometryDifferences.map(item=>Math.abs(item.delta)));
  check(result.maxRestoredGeometryDelta<=.01,item.id+': restored geometry violates .01px contract');
  check(!result.beforeNotice?.busy&&result.beforeNotice?.state!=='refreshing',item.id+': before notice is still refreshing');
  result.plotTop={before:item.before.geometry.plot?.top??null,shifted:item.shifted.geometry.plot?.top??null,restored:item.restored.geometry.plot?.top??null};
  return result;
});
const npmEntry=execution.executions.find(item=>item.id==='npm-test');
const npmLog=(await read(resolve(dirname(executionFile),npmEntry.log))).toString('utf8');
const totals=[...npmLog.matchAll(/^ATLAS_TEST_TOTAL (\{[^\n]+\})\s*$/gm)];
assert.equal(totals.length,1,'Require exactly one original ATLAS_TEST_TOTAL receipt');
const npm=JSON.parse(totals[0][1]);
check(npm.complete===true&&[npm.tests,npm.pass,npm.fail,npm.skipped,npm.batches].every(Number.isFinite),'Incomplete npm count receipt');
check(npm.fail===0,'npm test failures');

const diagnosticReports=[...reports].filter(([file,report])=>file.startsWith(diagnosticRoot+sep)&&Array.isArray(report.cases));
const diagnosticProductSourceIntegrity=diagnosticReports.map(([file,report])=>{
  const files=Object.entries(report.sourceHashes||{}).filter(([path])=>path.startsWith('dist/'));
  const changedSources=files.filter(([path,hash])=>conference.sourceHashes?.[path]!==hash).map(([path])=>path);
  assert.ok(files.length>0,'Diagnostic product inventory missing: '+file);
  assert.deepEqual(changedSources,[],'Diagnostic product differs from final tested product: '+file);
  return {report:inside(diagnosticRoot,file),checkedFiles:files.length,changedSources};
});
const diagnosticSummary={scope:'Diagnostic executions only; excluded from final acceptance totals',reports:diagnosticReports.map(([file,report])=>({
  report:inside(diagnosticRoot,file),status:report.status,sourceCommit:report.sourceCommit??null,workingChanges:report.workingChanges??null,
  counts:{total:report.cases.length,passed:report.cases.filter(item=>passed(item.status)).length,failed:report.cases.filter(item=>!passed(item.status)).length},
  failures:report.failures??[],cases:report.cases.map(item=>({id:item.id,status:item.status,failures:item.failures??[],eventTrace:item.eventTrace??null,afterDocumentLoad:item.afterDocumentLoad??null}))}))};
const knownFile=resolve(diagnosticRoot,'navigation-font-response-race-3/report.json');
const known=reports.get(knownFile);
assert.ok(known&&known.status==='failed'&&known.cases.length===1&&!passed(known.cases[0].status),'Known early-load product failure must remain recorded as FAILED 0/1');

const archive=new Map(), manifestEntries=[];
function add(file,bytes,detail){assert.ok(!archive.has(file),'Duplicate packed path: '+file);archive.set(file,bytes);manifestEntries.push({file,bytes:bytes.length,sha256:sha(bytes),...detail});}
const archiveGroups=[[acceptanceFiles,runRoot,''],[diagnosticFiles,diagnosticRoot,'diagnostics/'],[interruptedFiles,interruptedRoot,'interrupted-attempt-1/']];
for(const [files,base,prefix] of archiveGroups)for(const source of files){
  const original=await read(source),compressed=gzipSync(original,{level:9});
  assert.equal(sha(gunzipSync(compressed)),sha(original));
  add(prefix+inside(base,source)+'.gz',compressed,{kind:'original-gzip',source:inside(root,source),originalBytes:original.length,originalSha256:sha(original)});
}
const representative=[reportFile('heading/compare-320.png'),reportFile('heading/compare-390.png'),
  reportFile('conference/fixture-320x740.png'),reportFile('conference/fixture-1440x900.png'),
  resolve(diagnosticRoot,'navigation-font-response-race-3/navigation-ETHUSD-failed.png'),
  ...(interruptedSummary?[resolve(interruptedRoot,'conference/fixture-1440x900-failed.png')]:[])];
for(const source of representative){
  const receipt=pngs.get(source);
  assert.ok(receipt,'Representative PNG missing from verified report receipts: '+source);
  const [,base,prefix]=archiveGroups.find(([,base])=>source.startsWith(base+sep));
  const file=prefix+inside(base,source);
  const bytes=await readFile(source);assert.equal(sha(bytes),receipt.sha256,'PNG changed after validation');
  receipt.retainedAs=file;add(file,bytes,{kind:'representative-png',source:inside(root,source)});
}
const summary={schemaVersion:1,kind:'r13-linux-harness-evidence',sourceCommit:expectedSource,sourceTree:execution.sourceTree,
  capturedAt:new Date().toISOString(),productionDeployment:false,environment:execution.environment,
  acceptance:{status:acceptanceIssues.length?'failed':'passed',
    scope:'Requested Linux harness gates only. Conference navigation is measured AFTER document complete, fonts loaded, and media/image readiness; it does not prove early-load playback survives pageshow.',
    counts:caseCounts,npm,issues:acceptanceIssues,executions:execution.executions.map(({id,exitCode,durationMs,logSha256,sourceUnchanged})=>({id,exitCode,durationMs,logSha256,sourceUnchanged}))},
  nativeSelect,headingMotion,
  postLoadNavigation:conference.cases.filter(item=>/^navigation-(BTCUSD|ETHUSD)$/.test(item.id)).map(item=>({id:item.id,status:item.status,
    readiness:item.conferenceReadiness??null,playClick:item.playClick??null,playing:item.playing?{playing:item.playing.state?.playing,audioPaused:item.playing.audio?.paused,audioTime:item.playing.audio?.time}:null})),
  knownUnresolvedProductDiagnostic:{status:'failed',total:1,passed:0,failed:1,excludedFromAcceptance:true,
    report:'diagnostics/navigation-font-response-race-3/report.json.gz',
    finding:'A trusted play click during initial document loading is subsequently paused by the genuine initial pageshow. Product code is unchanged; normal post-load conference success does not close this defect.'},
  pngVerification:{uniqueFiles:pngs.size,receiptReferences:[...pngs.values()].reduce((sum,item)=>sum+item.references.length,0),retainedFiles:representative.length,
    rule:'All referenced original PNG sizes, SHA-256 digests and signatures verified on disk; only the listed representative PNGs are committed.'},
  replayDownloadVerification:{uniqueFiles:replayDownloads.size,receiptReferences:[...replayDownloads.values()].reduce((sum,item)=>sum+item.references.length,0),retainedFiles:0,
    rule:'All generated model/replay JSON downloads were verified against original report sizes and SHA-256 digests. Their verified inventory is committed; the large generated payloads are not duplicated in Git.'},
  diagnostics:{reports:diagnosticSummary.reports.length,summary:'diagnostics/summary.json',productSourceIntegrity:diagnosticProductSourceIntegrity},
  interruptedAttempts:interruptedSummary?[interruptedSummary]:[]};
add('summary.json',jsonBytes(summary),{kind:'derived-summary'});
add('failures.json',jsonBytes({scope:'Acceptance only; original receipts remain authoritative',issues:acceptanceIssues,records:failureRecords}),{kind:'derived-failures'});
add('diagnostics/summary.json',jsonBytes(diagnosticSummary),{kind:'derived-diagnostics'});
if(interruptedSummary)add('interrupted-attempt-1/summary.json',jsonBytes(interruptedSummary),{kind:'derived-interrupted-attempt'});
add('png-verification.json',jsonBytes({verifiedAt:summary.capturedAt,files:[...pngs.values()].sort((a,b)=>a.source.localeCompare(b.source))}),{kind:'derived-png-manifest'});
add('replay-download-verification.json',jsonBytes({verifiedAt:summary.capturedAt,files:[...replayDownloads.values()].sort((a,b)=>a.source.localeCompare(b.source))}),{kind:'derived-download-manifest'});
const manifest={schemaVersion:1,kind:'r13-evidence-integrity',sourceCommit:expectedSource,createdAt:summary.capturedAt,
  note:'Original report/log/probe byte streams are gzip-compressed unchanged. SHA-256 and byte counts cover both original and stored bytes. PNG and replay-download manifests distinguish verified-only generated payloads from retained representatives.',
  files:manifestEntries.sort((a,b)=>a.file.localeCompare(b.file))};
archive.set('manifest.json',jsonBytes(manifest));
archive.set('SHA256SUMS',Buffer.from([...archive].sort(([a],[b])=>a.localeCompare(b)).map(([file,bytes])=>sha(bytes)+'  '+file).join('\n')+'\n'));

// All input/identity checks precede writes. Refuse to overwrite an earlier pack.
try { await lstat(output); throw new Error('Evidence output already exists; choose a fresh --out: '+output); }
catch(error){if(error.code!=='ENOENT')throw error;}
for(const [file,bytes] of inputBytes)assert.equal(sha(await readFile(file)),sha(bytes),'Input changed while packing: '+file);
assert.equal(git(['rev-parse','HEAD']),expectedSource,'HEAD changed while packing');
const staging=output+'.staging-'+process.pid;
await mkdir(staging,{recursive:false});
try {
  for(const [file,bytes] of archive){const target=resolve(staging,file);inside(staging,target);await mkdir(dirname(target),{recursive:true});await writeFile(target,bytes);}
  await rename(staging,output);
}catch(error){await rm(staging,{recursive:true,force:true});throw error;}
console.log(JSON.stringify({output,status:summary.acceptance.status,sourceCommit:expectedSource,files:archive.size,storedBytes:[...archive.values()].reduce((sum,bytes)=>sum+bytes.length,0),
  counts:caseCounts,npm,nativeSelect,pngVerification:summary.pngVerification,knownUnresolvedProductDiagnostic:summary.knownUnresolvedProductDiagnostic}));
if(summary.acceptance.status!=='passed')process.exitCode=1;
