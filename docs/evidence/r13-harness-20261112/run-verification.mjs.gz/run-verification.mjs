// Task-local orchestration. Repository harnesses and thresholds run unchanged.
import assert from 'node:assert/strict';
import {spawn, execFileSync} from 'node:child_process';
import {createWriteStream} from 'node:fs';
import {readFile, writeFile, mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve, dirname} from 'node:path';
import {fileURLToPath} from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const out = resolve(root, 'build/r13/verification');
const runtimeBin = '/workspace/scratch/55a6bfaf803b/conference-tools/node-v24.22.2-linux-x64/bin';
const node = resolve(runtimeBin, 'node'), npm = resolve(runtimeBin, 'npm');
const browser = '/workspace/scratch/55a6bfaf803b/conference-tools/chrome-with-proxy';
const xdg = '/workspace/scratch/a7a56e32088b/browser-r13-runtime/xdg-data';
const git = args => execFileSync('git', args, {cwd:root,encoding:'utf8'}).trim();
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const head = git(['rev-parse','HEAD']);
const env = {...process.env, PATH:'/Applications/Docker.app/Contents/Resources/bin:'+runtimeBin+':'+process.env.PATH,
  ATLAS_BROWSER_PATH:browser, XDG_DATA_HOME:xdg, ETH_BROWSER_IMAGE_LOG_MODE:'failures-only'};
delete env.ATLAS_BROWSER_LANE; delete env.ATLAS_BROWSER_SUITE_RUN_ID;
const paths = ['scripts/verify-conference-browser.mjs','scripts/verify-page-heading-browser.mjs','scripts/native-select-keyboard.mjs',
  'scripts/verify-native-browser-suite.mjs','scripts/verify-eth-candidate-browser.mjs','scripts/verify-responsive-workbench-browser.mjs',
  'scripts/verify-wp6-browser.mjs','scripts/verify-wp6-cloudflare.mjs','scripts/verify-chart-qa-metrics.mjs','scripts/test.mjs',
  'dist/conference/player.js','dist/app.js','dist/btc-refresh-status.js','dist/ui/page-description.js','dist/atlas-shell.css'];
async function snapshot() {
  assert.equal(git(['rev-parse','HEAD']), head, 'HEAD changed during verification');
  git(['diff','--exit-code','HEAD','--','dist','scripts','tests']);
  return Object.fromEntries(await Promise.all(paths.map(async file=>[file,sha(await readFile(resolve(root,file)))])));
}
await mkdir(out,{recursive:true});
const report = {kind:'r13-linux-verification',startedAt:new Date().toISOString(),sourceCommit:head,
  sourceTree:git(['rev-parse','HEAD^{tree}']),sourceHashes:await snapshot(),productionDeployment:false,
  environment:{platform:process.platform,arch:process.arch,node:execFileSync(node,['--version'],{encoding:'utf8'}).trim(),browser,
    browserLauncherSha256:sha(await readFile(browser)),xdgDataHome:xdg,dockerPathAdded:'/Applications/Docker.app/Contents/Resources/bin',
    frozenRuntime:'native canonical Node 24.22.2 linux/x64'},executions:[],status:'running'};
const save = () => writeFile(resolve(out,'executions.json'),JSON.stringify(report,null,2)+'\n');
let current;
for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>{if(current?.pid)try{process.kill(-current.pid,signal);}catch{}process.exitCode=1;});
async function run(id,command,args,extra={}) {
  assert.deepEqual(await snapshot(),report.sourceHashes);
  const entry={id,command:[command,...args],cwd:root,startedAt:new Date().toISOString(),log:id+'.log'};
  report.executions.push(entry);await save();console.log(JSON.stringify({event:'start',id,startedAt:entry.startedAt}));
  const log=createWriteStream(resolve(out,entry.log));
  current=spawn(command,args,{cwd:root,env:{...env,...extra},detached:true,stdio:['ignore','pipe','pipe']});
  let error=null;current.once('error',value=>{error=String(value);});
  for(const input of [current.stdout,current.stderr]) {
    let buffer='';
    input.on('data',bytes=>{log.write(bytes);buffer+=bytes.toString();let offset;
      while((offset=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,offset);buffer=buffer.slice(offset+1);
        if(line.startsWith('ETH_BROWSER_RECEIPT ')||line.startsWith('ETH_BROWSER_LANE_RECEIPT ')||line.startsWith('ETH_BROWSER_FAST_CADENCE_RELEASE ')||
          line.startsWith('ATLAS_TEST_TOTAL ')||/^\{"(?:id|event|status)":/.test(line))console.log(line);
      }
    });
  }
  const outcome=await new Promise(accept=>current.once('close',(code,signal)=>accept({code,signal})));current=null;
  await new Promise(accept=>log.end(accept));
  entry.finishedAt=new Date().toISOString();entry.durationMs=Date.parse(entry.finishedAt)-Date.parse(entry.startedAt);
  entry.exitCode=outcome.code;entry.signal=outcome.signal;entry.error=error;
  const bytes=await readFile(resolve(out,entry.log));entry.logBytes=bytes.length;entry.logSha256=sha(bytes);
  entry.resultTail=bytes.toString().split('\n').slice(-8).join('\n');
  assert.deepEqual(await snapshot(),report.sourceHashes);entry.sourceUnchanged=true;await save();
  console.log(JSON.stringify({event:'finish',id,exitCode:entry.exitCode,durationMs:entry.durationMs}));
}
await run('conference',node,['scripts/verify-conference-browser.mjs','--out','build/r13/conference']);
await run('heading',node,['scripts/verify-page-heading-browser.mjs','--out','build/r13/heading']);
await run('native-53',node,['scripts/verify-native-browser-suite.mjs'],{ATLAS_BROWSER_OUT:'build/r13/native-53',ATLAS_BROWSER_CASE_SCOPE:'all'});
await run('r10-regressions',node,['docs/evidence/chart-h1-20261112/r10-browser-gates.mjs',root,head,'build/r13/r10']);
await run('npm-test',npm,['test','--','--test-concurrency=4']);
report.finishedAt=new Date().toISOString();report.status=report.executions.every(entry=>entry.exitCode===0)?'passed':'failed';
await save();console.log(JSON.stringify({event:'complete',status:report.status,out}));
process.exitCode=report.status==='passed'?0:1;
