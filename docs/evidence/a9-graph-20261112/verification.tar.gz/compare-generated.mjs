import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
const independent=JSON.parse(fs.readFileSync('build/a9-graph/static-closure-audit.json'));
const manifestBytes=fs.readFileSync('docs/conference/boot-preload-graph.json');
const actual=JSON.parse(manifestBytes);
const differences=[];
const compare=(label,left,right)=>{try{assert.deepEqual(left,right);}catch{differences.push({label,actual:left,expected:right});}};
compare('root order',actual.roots,independent.roots);
compare('module BFS order',actual.modules.map(m=>m.url),independent.combined.rows.map(m=>m.url));
for(const module of actual.modules){
 const expected=independent.combined.rows.find(m=>m.url===module.url);if(!expected){differences.push({label:'unexpected URL',url:module.url});continue;}
 for(const field of ['file','bytes','sha256','depth'])compare(module.url+' '+field,module[field],expected[field]);
 const edges=independent.combined.edges.filter(edge=>edge.from===module.url).map(edge=>({specifier:edge.specifier,url:edge.to}));
 compare(module.url+' static imports in source order',module.imports,edges);
}
compare('module hints order',actual.modulePreloads,['./conference/timeline.js',...independent.combined.rows.map(r=>r.url).filter(url=>url!==actual.sharedModulePreload&&url!=='./conference/timeline.js')]);
compare('full hint URL count',new Set([actual.sharedModulePreload,...actual.modulePreloads]).size,55);
for(const field of ['url','bytes','sha256'])compare('timeline '+field,actual.timeline[field],independent.timeline[field]);
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
compare('generator SHA256',actual.generator.sha256,hash(fs.readFileSync(actual.generator.file)));
const html=fs.readFileSync('dist/index.html','utf8');const script=html.match(/<script id="atlas-boot-preloads">([\s\S]*?)<\/script>/)[1];
assert.ok(script.includes(hash(manifestBytes)));
const moduleFiles=[...new Set(actual.modules.map(r=>'dist/'+r.file))];
for(const file of [...moduleFiles,'dist/conference/timeline.json'])compare(file+' original HEAD bytes',hash(fs.readFileSync(file)),hash(execFileSync('git',['show','HEAD:'+file])));
function execute(search,entryUrl){const links=[];let queries=0;vm.runInNewContext(script,{URL,URLSearchParams,location:{search},document:{querySelector(selector){queries++;assert.equal(selector,'link[rel="modulepreload"]');return{href:entryUrl};},createElement(tag){assert.equal(tag,'link');return{};},head:{append(link){links.push({...link});}}}});return{links,queries};}
const bases=[{name:'origin root',entry:'https://atlas.invalid/site-entry.js?v=1.37.8',root:'https://atlas.invalid/'},{name:'project root',entry:'https://atlas.invalid/bitcoin-cycle-atlas/site-entry.js?v=1.37.8',root:'https://atlas.invalid/bitcoin-cycle-atlas/'},{name:'nested wrapper after href rebasing',entry:new URL('../../site-entry.js?v=1.37.8','https://atlas.invalid/bitcoin-cycle-atlas/market-lab/charts/?page=conference').href,root:'https://atlas.invalid/bitcoin-cycle-atlas/'}];
for(const base of bases){const result=execute('?page=conference&symbol=ETHUSD&t=18025.63',base.entry);compare(base.name+' hint count',result.links.length,55);compare(base.name+' timeline attributes',result.links[0],{rel:'preload',as:'fetch',crossOrigin:'anonymous',fetchPriority:'high',href:new URL('./conference/timeline.json',base.root).href});compare(base.name+' module URL targets',result.links.slice(1).map(l=>l.href),actual.modulePreloads.map(href=>new URL(href,base.root).href));assert.ok(result.links.slice(1).every(l=>l.rel==='modulepreload'));}
const inactive=['','?page=outlook','?page=compare','?page=evidence','?page=data','?page=ipo','?page=market','?page=relay','?symbol=ETHUSD','?symbol=MSTR','?symbol=BMNR','?symbol=TQQQ','?page=conference-unknown'];for(const search of inactive)compare('inactive route '+search,execute(search,bases[0].entry),{links:[],queries:0});
const offline=html.replace(/\s*<script\b[^>]*id="atlas-boot-preloads"[^>]*>[\s\S]*?<\/script>/,'').replace(/\s*<link\b(?=[^>]*\brel=["']modulepreload["'])[^>]*>/gi,'');compare('offline hints removed',/atlas-boot-preloads|rel="modulepreload"|timeline\.crossOrigin|timeline\.as/.test(offline),false);
const result={status:differences.length?'failed':'ok',comparedCommit:independent.sourceCommit,modules:actual.modules.length,physicalFiles:moduleFiles.length,staticEdges:actual.modules.reduce((sum,m)=>sum+m.imports.length,0),sourceHashesMatched:moduleFiles.length+1,baseCases:bases.length,inactiveRoutes:inactive.length,differences};fs.writeFileSync('build/a9-graph/generated-comparison.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));assert.equal(differences.length,0);
