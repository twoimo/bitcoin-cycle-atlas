import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import {buildSync,version as esbuildVersion} from 'esbuild';
import {execFileSync} from 'node:child_process';

const dist=path.resolve('dist'), base=new URL('https://atlas.invalid/bitcoin-cycle-atlas/');
const rootUrls=['./site-entry.js?v=1.37.8','./app.js?v=1.37.8','./conference/player.js?v=1.0.0'].map(p=>new URL(p,base).href);
const parsed=new Map();
function moduleData(url){
 const canonical=new URL(url);const pathname=decodeURIComponent(canonical.pathname.slice(base.pathname.length));
 if(canonical.origin!==base.origin||!canonical.pathname.startsWith(base.pathname))throw Error('Escaping module URL '+url);
 const file=path.resolve(dist,pathname);if(!file.startsWith(dist+path.sep))throw Error('Escaping path '+file);
 if(!parsed.has(file)){
  const bytes=fs.readFileSync(file),source=bytes.toString('utf8');
  const result=buildSync({stdin:{contents:source,sourcefile:file},bundle:false,write:false,metafile:true,format:'esm',treeShaking:false,logLevel:'silent'});
  const imports=Object.values(result.metafile.outputs).flatMap(output=>output.imports);
  const statics=imports.filter(item=>item.kind==='import-statement').map(item=>item.path);
  const dynamics=imports.filter(item=>item.kind==='dynamic-import').map(item=>item.path);
  parsed.set(file,{file:path.relative(dist,file).split(path.sep).join('/'),bytes:bytes.length,gzipBytes:zlib.gzipSync(bytes,{level:9}).length,sha256:crypto.createHash('sha256').update(bytes).digest('hex'),statics,dynamics});
 }
 return parsed.get(file);
}
function closure(roots){
 const queue=roots.map(url=>({url,depth:0})),nodes=new Map(),edges=[];
 while(queue.length){const {url,depth}=queue.shift();if(nodes.has(url))continue;const data=moduleData(url);
  nodes.set(url,{url:'./'+url.slice(base.href.length),depth,...data});
  for(const specifier of data.statics){if(!/^\.\.?\//.test(specifier))throw Error('Nonrelative '+specifier);const target=new URL(specifier,url).href;edges.push({from:url,to:target,specifier});queue.push({url:target,depth:depth+1});}
 }
 const rows=[...nodes.values()];const grouped=new Map();for(const r of rows)grouped.set(r.file,[...(grouped.get(r.file)||[]),r.url]);
 return {nodes:rows.length,uniqueFiles:grouped.size,edges:edges.length,maximumShortestDepth:Math.max(...rows.map(r=>r.depth)),depthCounts:Object.fromEntries([...new Set(rows.map(r=>r.depth))].sort((a,b)=>a-b).map(d=>[d,rows.filter(r=>r.depth===d).length])),bytes:rows.reduce((n,r)=>n+r.bytes,0),gzipBytes:rows.reduce((n,r)=>n+r.gzipBytes,0),duplicateFiles:[...grouped].filter(([,urls])=>urls.length>1).map(([file,urls])=>({file,urls})),rows,edges:edges.map(e=>({...e,from:'./'+e.from.slice(base.href.length),to:'./'+e.to.slice(base.href.length)}))};
}
const perRoot=rootUrls.map(root=>({root:'./'+root.slice(base.href.length),...closure([root])})),combined=closure(rootUrls),timeline=fs.readFileSync(path.join(dist,'conference/timeline.json'));
const report={sourceCommit:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),parser:'esbuild '+esbuildVersion+' nonbundled module parser, output import-statement edges (independent of production scanner)',base:base.href,roots:rootUrls.map(r=>'./'+r.slice(base.href.length)),perRoot,combined,timeline:{url:'./conference/timeline.json',bytes:timeline.length,gzipBytes:zlib.gzipSync(timeline,{level:9}).length,sha256:crypto.createHash('sha256').update(timeline).digest('hex')}};
fs.writeFileSync('build/a9-graph/static-closure-audit.json',JSON.stringify(report,null,2)+'\n');
const summarize=({nodes,uniqueFiles,maximumShortestDepth,depthCounts,bytes,gzipBytes,duplicateFiles})=>({nodes,uniqueFiles,maximumShortestDepth,depthCounts,bytes,gzipBytes,duplicateFiles});
console.log(JSON.stringify({sourceCommit:report.sourceCommit,perRoot:perRoot.map(row=>({root:row.root,...summarize(row)})),combined:summarize(combined),timeline:report.timeline},null,2));
