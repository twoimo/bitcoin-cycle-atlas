import {spawn, execFileSync} from 'node:child_process';
import {createWriteStream} from 'node:fs';
import {mkdir, writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
const [label, command, ...args] = process.argv.slice(2);
if (!/^[a-z0-9-]+$/.test(label || '') || !command) throw Error('label and command required');
const directory=resolve('build/a9-graph/results'); await mkdir(directory,{recursive:true});
const result={command:[command,...args],cwd:process.cwd(),startedAt:new Date().toISOString(),node:process.version,
 sourceCommit:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),
 workingChanges:execFileSync('git',['status','--porcelain'],{encoding:'utf8'}).trim(),complete:false};
const json=resolve(directory,label+'.json'), log=createWriteStream(resolve(directory,label+'.log'),{flags:'wx'});
await writeFile(json,JSON.stringify(result,null,2)+'\n');
const started=performance.now();
const child=spawn(command,args,{stdio:['ignore','pipe','pipe']});
child.stdout.pipe(log,{end:false}); child.stderr.pipe(log,{end:false});
const outcome=await new Promise(accept=>{child.on('error',error=>accept({exit:1,error:String(error)}));child.on('close',(exit,signal)=>accept({exit,signal}));});
await new Promise(accept=>log.end(accept));
Object.assign(result,outcome,{complete:true,elapsedMs:performance.now()-started,finishedAt:new Date().toISOString()});
await writeFile(json,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result)); process.exitCode=result.exit??1;
