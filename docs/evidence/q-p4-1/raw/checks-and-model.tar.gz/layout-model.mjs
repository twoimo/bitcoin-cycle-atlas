// Explicitly injected layout model. This is NOT a browser/native render result.
// The authored controller runs unchanged; every dimension comes from the inputs below.
import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {parseHTML} from 'linkedom';
import {mountConferencePlayer} from '../../../dist/conference/player.js';

const sourceFiles = ['dist/conference/player.js', 'dist/conference/player.css'];
const digest = async path => createHash('sha256').update(await readFile(new URL('../../../' + path, import.meta.url))).digest('hex');
const sourceBefore = Object.fromEntries(await Promise.all(sourceFiles.map(async path => [path, await digest(path)])));
const timeline = JSON.parse(await readFile(new URL('../../../tests/fixtures/conference/timeline.synthetic.json', import.meta.url)));
const report = {
  schemaVersion:1, kind:'conference-layout-injected-model', nativeEvidence:false,
  nativeBrowserAttempts:0, nativeBrowserPasses:0, sourceBefore,
  limitations:[
    'Linkedom does not render CSS or text. Widths/heights, wrapping thresholds, and computed styles are explicit model inputs.',
    'No native focus, paint, viewport overflow, media decode, scroll, or font behavior is proved.',
    'Synthetic fixture data and a media element stub exercise the real controller only.'
  ],
  assumptions:{hostBorderEach:1, bandMainPaddingInlineEach:8, bandCaptionHeight:48,
    baseHeaderHeight:44, baseControlsHeight:163, modelWrapThreshold:600,
    extraWrappedOptionsRow:48, noticeExtraHeight:21, retryExtraHeight:55,
    clientDimensions:'rounded to integer; modeled box dimensions retained as floating point'},
  cases:[]
};

function createModel() {
  const {document, window} = parseHTML('<html><body data-page="conference"><h1>컨퍼런스 복습</h1><main id="parent"><section id="host"></section></main></body></html>');
  const host = document.getElementById('host'), parent = document.getElementById('parent');
  const input = {viewportWidth:1024, viewportHeight:768, parentWidth:760, parentHeight:676,
    headerBase:44, headerWrap:false, headerWrapThreshold:700, headerWrapExtra:36,
    controlsWrap:true, controlsWrapThreshold:600, extraControls:0, fullWidth:1024, fullHeight:768};
  const events = new window.EventTarget(), frames = new Map(), operations = [];
  let nextFrame = 1, scheduled = 0, cancelled = 0, observer, responseMode = 'ready';
  let location = new URL('https://atlas.test/bitcoin-cycle-atlas/?page=conference&t=0&deck=final-290');
  class ModelResizeObserver {
    targets = []; disconnected = false;
    constructor(callback) { this.callback = callback; observer = this; }
    observe(node) { this.targets.push(node); }
    disconnect() { this.disconnected = true; }
  }
  const view = {
    get location() { return location; }, get innerWidth() { return input.viewportWidth; },
    ResizeObserver:ModelResizeObserver,
    history:{state:null, replaceState(_state, _title, url) { location = new URL(url, location); }},
    addEventListener:events.addEventListener.bind(events), removeEventListener:events.removeEventListener.bind(events),
    dispatchEvent:events.dispatchEvent.bind(events), getSelection:() => ({toString:() => ''}),
    requestAnimationFrame(callback) { const id = nextFrame++; frames.set(id, callback); scheduled++; return id; },
    cancelAnimationFrame(id) { if (frames.delete(id)) cancelled++; },
    getComputedStyle(node) {
      const band = input.viewportWidth >= 1024 && input.viewportWidth <= 1279;
      const padding = node.classList?.contains('conference-main') ? (band ? [0,8,0,8] : input.viewportWidth >= 1280 ? [12,16,0,16] : [8,8,0,8]) : [0,0,0,0];
      return {paddingTop:padding[0]+'px', paddingRight:padding[1]+'px', paddingBottom:padding[2]+'px', paddingLeft:padding[3]+'px',
        borderLeftWidth:node===host?'1px':'0px', borderRightWidth:node===host?'1px':'0px',
        display:node.hidden?'none':'block', visibility:'visible', opacity:'1'};
    }
  };
  const media = document.createElement('audio');
  media.currentTime=0; media.paused=true; media.ended=false; media.playbackRate=1;
  Object.defineProperty(media, 'src', {get:() => media.getAttribute('src') || '', set:value => media.setAttribute('src', value)});
  media.load=()=>{}; media.pause=()=>{media.paused=true; media.dispatchEvent(new window.Event('pause'));};
  media.play=async()=>{media.paused=false;};
  Object.defineProperty(document, 'fullscreenElement', {configurable:true,writable:true,value:null});
  const controller = mountConferencePlayer(host, {document,window:view,mediaElement:media,
    timelineUrl:'https://atlas.test/bitcoin-cycle-atlas/conference/timeline.json',
    fetchImpl:async()=>responseMode==='ready'?{ok:true,status:200,json:async()=>structuredClone(timeline)}:
      responseMode==='empty'?{ok:false,status:404}:{ok:false,status:500}});
  const query = selector => host.querySelector(selector), role = name => query('[data-role="'+name+'"]');
  const action = name => query('[data-action="'+name+'"]');
  const main=query('.conference-main'), visual=query('.conference-visual'), stage=query('.conference-stage');
  const header=query('.conference-stage-header'), caption=query('.conference-caption'), controls=query('.conference-controls');
  const panel=query('.conference-transcript'), shell=query('.conference-stage-shell');
  const noticeNode=role('notice'), retryNode=action('retry');
  Object.defineProperty(panel,'open',{get:()=>panel.hasAttribute('open')});
  panel.show=()=>panel.setAttribute('open',''); panel.showModal=()=>panel.setAttribute('open',''); panel.close=()=>panel.removeAttribute('open');
  for (const select of host.querySelectorAll('select')) Object.defineProperty(select,'value',{
    get(){return this.querySelector('option[selected]')?.value || this.querySelector('option')?.value || '';},
    set(value){for(const option of this.querySelectorAll('option')) option.toggleAttribute('selected',option.value===String(value));}
  });
  function instrument(node,label) {
    const original=node.style;
    const record=(property,before,after,operation)=>operations.push({node:label,property,before,after,operation,changed:before!==after});
    const proxy=new Proxy(original,{
      get(target,property){
        if(property==='setProperty') return (name,value,...rest)=>{const before=target.getPropertyValue(name);target.setProperty(name,value,...rest);record(name,before,target.getPropertyValue(name),'setProperty');};
        if(property==='removeProperty') return name=>{const before=target.getPropertyValue(name);const result=target.removeProperty(name);record(name,before,target.getPropertyValue(name),'removeProperty');return result;};
        const value=Reflect.get(target,property,target);return typeof value==='function'?value.bind(target):value;
      },
      set(target,property,value){const before=target[property];Reflect.set(target,property,value,target);record(String(property),before,target[property],'assignment');return true;}
    });
    Object.defineProperty(node,'style',{configurable:true,get:()=>proxy});
  }
  instrument(host,'host');instrument(stage,'stage');
  const cap=()=>Number.parseFloat(host.style.getPropertyValue('--conference-frame-width'));
  const band=()=>input.viewportWidth>=1024&&input.viewportWidth<=1279;
  const hostWidth=()=>band()&&Number.isFinite(cap())?Math.min(input.parentWidth,cap()):input.parentWidth;
  const dockWidth=()=>panel.open&&panel.dataset.mode==='dock'?320:0;
  const mainWidth=()=>Math.max(0,hostWidth()-2-dockWidth());
  const pads=()=>{const s=view.getComputedStyle(main);return {x:parseFloat(s.paddingLeft)+parseFloat(s.paddingRight),y:parseFloat(s.paddingTop)+parseFloat(s.paddingBottom)};};
  const visualWidth=()=>Math.max(0,mainWidth()-pads().x);
  const captionHeight=()=>band()?48:56;
  const controlsHeight=()=>163+(input.controlsWrap&&visualWidth()<input.controlsWrapThreshold?48:0)
    +(noticeNode.hidden?0:21)+(retryNode.hidden?0:55)+input.extraControls;
  const headerHeight=()=>input.headerBase+(input.headerWrap&&visualWidth()<input.headerWrapThreshold?input.headerWrapExtra:0);
  const mainHeight=()=>Math.max(0,input.parentHeight-2);
  const visualHeight=()=>Math.max(0,mainHeight()-pads().y-captionHeight()-controlsHeight());
  Object.defineProperty(parent,'clientWidth',{get:()=>Math.round(input.parentWidth)});
  Object.defineProperties(host,{clientWidth:{get:()=>Math.round(hostWidth()-2)},clientHeight:{get:()=>Math.round(mainHeight())}});
  Object.defineProperties(main,{clientWidth:{get:()=>Math.round(mainWidth())},clientHeight:{get:()=>Math.round(mainHeight())}});
  Object.defineProperties(visual,{clientWidth:{get:()=>Math.round(visualWidth())},clientHeight:{get:()=>Math.round(visualHeight())}});
  Object.defineProperties(caption,{clientWidth:{get:()=>Math.round(Math.min(visualWidth(),1120))},offsetHeight:{get:()=>Math.round(captionHeight())}});
  Object.defineProperty(controls,'offsetHeight',{get:()=>Math.round(controlsHeight())});
  Object.defineProperty(header,'offsetHeight',{get:()=>Math.round(headerHeight())});
  Object.defineProperty(panel,'offsetWidth',{get:()=>dockWidth()});
  Object.defineProperties(shell,{clientWidth:{get:()=>Math.round(input.fullWidth)},clientHeight:{get:()=>Math.round(input.fullHeight)}});
  const snapshot=()=>({input:{...input},cap:host.style.getPropertyValue('--conference-frame-width'),hostWidth:hostWidth(),mainWidth:mainWidth(),mainHeight:mainHeight(),
    visualWidth:visualWidth(),visualHeight:visualHeight(),headerHeight:headerHeight(),captionHeight:captionHeight(),controlsHeight:controlsHeight(),dockWidth:dockWidth(),
    stageWidth:Number.parseFloat(stage.style.width),stageHeight:Number.parseFloat(stage.style.height),
    noticeVisible:!noticeNode.hidden,retryVisible:!retryNode.hidden,fullscreen:document.fullscreenElement===shell,pendingFrames:frames.size});
  const notify=()=>observer.callback(observer.targets.map(target=>({target})));
  const flush=()=>{const pending=[...frames];frames.clear();for(const [,callback] of pending)callback(0);return pending.length;};
  function settleLayout(){
    let iterations=0;
    for(;iterations<30;iterations++){
      const before=JSON.stringify(snapshot());notify();flush();const after=JSON.stringify(snapshot());
      if(before===after)return iterations+1;
    }
    throw new Error('Model did not settle within 30 observer/frame deliveries');
  }
  const resize=changes=>{Object.assign(input,changes);view.dispatchEvent(new window.Event('resize'));return settleLayout();};
  const click=name=>action(name).dispatchEvent(new window.Event('click',{bubbles:true}));
  const fullscreen=on=>{document.fullscreenElement=on?shell:null;document.dispatchEvent(new window.Event('fullscreenchange'));return settleLayout();};
  return {input,document,window,view,host,parent,controller,media,observer,frames,operations,stage,role,action,
    snapshot,notify,flush,settleLayout,resize,click,fullscreen,
    clearOperations:()=>{operations.length=0;},counts:()=>({scheduled,cancelled,pending:frames.size}),
    setResponse:mode=>{responseMode=mode;}};
}

const model=createModel();
const near=(actual,expected,label,tolerance=1e-7)=>assert.ok(Math.abs(actual-expected)<=tolerance,label+': '+actual+' vs '+expected);
const fit=()=>{const s=model.snapshot();assert.ok(Math.abs(s.stageWidth-s.visualWidth)<=1,'stage spans actual modeled visual width');near(s.stageHeight,s.stageWidth*9/16,'16:9');assert.ok(s.headerHeight+s.stageHeight<=s.visualHeight+0.51,'stage and header fit visual');assert.ok(s.visualHeight+s.captionHeight+s.controlsHeight<=s.mainHeight+0.51,'bottom rows fit main');return s;};
async function check(id,run){try{const detail=await run();report.cases.push({id,status:'passed',...(detail?{detail}:{}),snapshot:model.snapshot()});}catch(error){report.cases.push({id,status:'failed',error:String(error.stack||error),snapshot:model.snapshot()});console.error(id+': '+error.message);}}

await check('1024x768-restored-shell',async()=>{assert.equal(await model.controller.load(),true);model.settleLayout();const s=fit();near(s.visualWidth,742,'visual width');near(s.stageWidth,742,'stage width');near(s.stageHeight,417.375,'stage height');});
await check('1279x768-whole-card-height-cap',()=>{model.resize({viewportWidth:1279,parentWidth:1015});const s=fit();near(s.stageHeight,419,'height budget');assert.ok(s.hostWidth<1015);near(s.hostWidth-s.visualWidth,18,'card borders and main padding');});
await check('1279x900-taller-parent',()=>{model.resize({viewportHeight:900,parentHeight:808});const s=fit();near(s.stageHeight,551,'taller stage');});
await check('parent-width-shrink',()=>{model.resize({parentWidth:620});near(fit().stageWidth,602,'narrow parent');});
await check('parent-width-restore',()=>{model.resize({parentWidth:1015});near(fit().stageHeight,551,'parent restores unrestricted height fit');});
await check('parent-height-shrink',()=>{model.resize({parentHeight:600});near(fit().stageHeight,343,'short parent');});
await check('parent-height-restore',()=>{model.resize({parentHeight:808});near(fit().stageHeight,551,'height restores');});
await check('dock-opens-320',()=>{model.click('transcript');model.settleLayout();const s=fit();assert.equal(s.dockWidth,320);near(s.stageWidth,677,'dock consumes actual width');});
await check('dock-closes-and-grows',()=>{model.click('close-transcript');model.settleLayout();assert.equal(fit().dockWidth,0);near(fit().stageHeight,551,'dock close restores frame');});
await check('notice-row-growth',()=>{model.media.dispatchEvent(new model.window.Event('error'));model.settleLayout();const s=fit();assert.equal(s.noticeVisible,true);assert.equal(s.controlsHeight,184);near(s.stageHeight,530,'notice reserves height',0.51);});
await check('notice-clears-on-reload',async()=>{await model.controller.load();model.settleLayout();assert.equal(fit().noticeVisible,false);near(fit().stageHeight,551,'notice removal restores');});
await check('retry-row-growth',async()=>{model.setResponse('error');assert.equal(await model.controller.load(),false);model.settleLayout();const s=fit();assert.equal(s.retryVisible,true);assert.equal(s.controlsHeight,218);near(s.stageHeight,496,'retry reserves height');});
await check('retry-clears-after-load',async()=>{model.setResponse('ready');assert.equal(await model.controller.load(),true);model.settleLayout();assert.equal(fit().retryVisible,false);near(fit().stageHeight,551,'retry removal restores');});
await check('header-and-settings-wrap-settle',()=>{model.resize({parentHeight:600,headerWrap:true});const s=fit();assert.equal(s.headerHeight,80);assert.equal(s.controlsHeight,211);near(s.stageHeight,259,'two measured wraps',0.51);});
await check('wrapped-height-restore',()=>{model.resize({parentHeight:808});const s=fit();assert.equal(s.headerHeight,44);assert.equal(s.controlsHeight,163);near(s.stageHeight,551,'external height change resets cap before measuring');});
await check('header-unwrapped-state',()=>{model.resize({headerWrap:false});near(fit().stageHeight,551,'unchanged geometry');});
await check('fullscreen-removes-whole-card-cap',()=>{model.notify();assert.equal(model.frames.size,1);const before=model.counts();model.fullscreen(true);const s=model.snapshot();assert.equal(s.cap,'');assert.equal(model.counts().cancelled-before.cancelled,1);near(s.stageWidth,1024,'fullscreen width');near(s.stageHeight,576,'fullscreen height');return {cancelledPendingFrame:1};});
await check('fullscreen-exit-restores-band-cap',()=>{model.fullscreen(false);assert.notEqual(fit().cap,'');near(fit().stageHeight,551,'fullscreen exit restores fit');});
await check('1023-clears-cap',()=>{model.notify();assert.equal(model.frames.size,1);const before=model.counts();model.resize({viewportWidth:1023,parentWidth:975,parentHeight:696});assert.equal(model.snapshot().cap,'');assert.equal(model.counts().cancelled-before.cancelled,1);return {cancelledPendingFrame:1};});
await check('1024-reenters-band',()=>{model.resize({viewportWidth:1024,parentWidth:760,parentHeight:676});near(fit().stageWidth,742,'band reentry');});
await check('1280-clears-cap',()=>{model.notify();assert.equal(model.frames.size,1);const before=model.counts();model.resize({viewportWidth:1280,parentWidth:1232,parentHeight:696});assert.equal(model.snapshot().cap,'');assert.ok(model.snapshot().stageWidth<=1120);assert.equal(model.counts().cancelled-before.cancelled,1);return {cancelledPendingFrame:1};});
await check('1279-reenters-band',()=>{model.resize({viewportWidth:1279,parentWidth:1015,parentHeight:808});near(fit().stageHeight,551,'band reentry 1279');});
await check('observer-burst-coalesces-to-one-frame',()=>{model.clearOperations();const before=model.counts();for(let i=0;i<5;i++)model.notify();assert.equal(model.frames.size,1);assert.equal(model.counts().scheduled-before.scheduled,1);assert.equal(model.operations.length,0);model.flush();assert.equal(model.frames.size,0);return {notifications:5,scheduledFrames:1};});
await check('unchanged-repeated-observer-writes-zero',()=>{model.clearOperations();for(let i=0;i<5;i++){model.notify();model.flush();}assert.equal(model.operations.length,0);return {deliveries:5,styleWriteAttempts:0};});
await check('resize-parent-in-queued-frame',()=>{model.input.parentWidth=620;model.notify();model.input.parentWidth=1015;model.flush();model.settleLayout();near(fit().stageHeight,551,'queued frame uses latest parent');});
await check('destroy-cancels-queued-frame',()=>{model.notify();assert.equal(model.frames.size,1);const queued=[...model.frames.values()][0],before=model.counts();model.controller.destroy();assert.equal(model.frames.size,0);assert.equal(model.counts().cancelled-before.cancelled,1);assert.equal(model.observer.disconnected,true);model.clearOperations();queued(0);model.notify();model.flush();assert.equal(model.operations.length,0);return {cancelledFrames:1,postDestroyStyleWrites:0};});

report.sourceAfter=Object.fromEntries(await Promise.all(sourceFiles.map(async path=>[path,await digest(path)])));
report.sourceStable=JSON.stringify(report.sourceBefore)===JSON.stringify(report.sourceAfter);
report.counts={required:report.cases.length,attempted:report.cases.length,passed:report.cases.filter(x=>x.status==='passed').length,failed:report.cases.filter(x=>x.status==='failed').length};
report.status=report.counts.failed===0&&report.sourceStable?'passed':'failed';
await writeFile(new URL('./layout-model.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({kind:report.kind,nativeEvidence:false,status:report.status,sourceStable:report.sourceStable,counts:report.counts}));
process.exitCode=report.status==='passed'?0:1;
